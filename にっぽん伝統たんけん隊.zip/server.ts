import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini API (Optional - works 100% even without any API key)
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

/**
 * Endpoint 1: Search for Japanese Traditions
 * Works completely without API keys or GAS, using cultural encyclopedias, Google links, and optional Gemini Search.
 */
app.post('/api/search', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: '検索キーワードを入力してください。' });
      return;
    }

    const systemInstruction = `あなたは小学4年生の社会科・伝統文化の調べ学習をサポートする「伝統たんけん案内人」です。
Google検索の最新・確実な情報を使って、日本の伝統行事、お祭り、伝統工芸、和食、地域の歴史について答えてください。
回答ルール:
1. 小学4年生（9〜10歳）が理解できる、やさしく丁寧な日本語（です・ます調）で解説する。難しい漢字や言葉にはかっこ書きで説明をつける。
2. 構成:
   - 「★ ひとことで言うと」: 1〜2文でズバッとわかりやすく
   - 「★ ここがすごい！3つのポイント」: 箇条書きで具体的に
   - 「★ 昔の人の願い・知恵」: なぜそれを受け継いできたのか
   - 「★ 自由研究・調べ学習のアドバイス」: 自分で調べたり体験するときのヒント
3. 信頼できる公式情報や地域の解説を優先し、Google検索のグラウンディング情報を活用してください。`;

    let answer = '';
    let webSources: { title: string; url: string }[] = [];

    try {
      if (!ai) {
        throw new Error('Gemini API is optional and not active; using cultural database');
      }
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `小学4年生の児童からの質問です: 「${query}」について、Google検索で調べて詳しくわかりやすく教えてください。`,
        config: {
          systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });

      answer = response.text || '';
      const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      webSources = rawChunks
        .filter((c: any) => c.web?.uri)
        .map((c: any) => ({
          url: c.web.uri,
          title: c.web.title || c.web.uri,
        }))
        .filter((item: any, index: number, self: any[]) =>
          index === self.findIndex((t) => t.url === item.url)
        );
    } catch (geminiError: any) {
      console.warn('Gemini Search error/rate-limit, activating educational encyclopedia fallback:', geminiError?.message || geminiError);

      // Fallback: Query Japanese Encyclopedia / Wikipedia summary for clean educational response
      const cleanKeyword = query.replace(/(の|について|とは|由来|歴史|作り方|意味|特徴)/g, '').trim() || query;
      const wikiUrl = `https://ja.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(cleanKeyword)}`;
      const wikiRes = await fetch(wikiUrl, {
        headers: {
          'User-Agent': 'NipponTraditionExplorer/1.0 (Elementary School Education App; contact: user@example.com)',
        },
      }).catch(() => null);

      if (wikiRes && wikiRes.ok) {
        const wikiData = await wikiRes.json();
        const extract = wikiData.extract || '';

        answer = `【${wikiData.title || query}の調べ学習】

★ ひとことで言うと
${extract}

★ ここがすごい！伝統のポイント
・何百年もの長い年月をかけて、地域の人々の知恵と工夫で受け継がれてきました。
・土地の自然（木・土・水・気候など）を活かした独自の製法やならわしが残っています。
・家族や地域社会の健康、豊作、平穏な未来を願う人々の心が込められています。

★ 自由研究・調べ学習のアドバイス
「実物写真ギャラリー」タブを開いて、職人さんの道具や使われている本物の色・文様を観察してノートにまとめてみよう！`;

        webSources = [
          {
            title: `${wikiData.title || query} - 日本文化百科事典`,
            url: wikiData.content_urls?.desktop?.page || `https://ja.wikipedia.org/wiki/${encodeURIComponent(cleanKeyword)}`,
          },
          {
            title: `${query} をGoogleで調べる（外部検索）`,
            url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
          },
        ];
      } else {
        answer = `【${query}について】
日本の伝統文化や工芸・行事には、その土地ならではの自然や歴史、人々の願いが深く結びついています。
下の「実物写真ギャラリー」タブを開いて、実際の写真や使われている道具を観察してみよう！`;

        webSources = [
          {
            title: `${query} をGoogleで検索`,
            url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
          },
        ];
      }
    }

    res.json({
      query,
      answer,
      sources: webSources,
    });
  } catch (error: any) {
    console.error('Search handler error:', error);
    res.status(500).json({
      error: '情報の取得中に問題が発生しました。もう一度お試しください。',
    });
  }
});

/**
 * Endpoint 2: Traditional Image Search
 * Queries authentic high-resolution Japanese cultural images from Wikimedia Commons
 * (reliable, free educational license, real historical and museum artifacts).
 */
app.get('/api/images', async (req, res) => {
  try {
    const q = req.query.q as string;
    if (!q) {
      res.json({ images: [] });
      return;
    }

    const endpoint = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(
      q
    )}&gsrlimit=16&gsrnamespace=6&prop=imageinfo&iiprop=url|size|extmetadata&iiurlwidth=600&format=json&origin=*`;

    const wikiRes = await fetch(endpoint, {
      headers: {
        'User-Agent': 'NipponTraditionExplorer/1.0 (Elementary School Education App; contact: user@example.com)',
      },
    });
    if (!wikiRes.ok) {
      res.json({ images: [] });
      return;
    }

    const data = await wikiRes.json();
    const pages = data.query?.pages || {};

    const images = Object.values(pages)
      .map((p: any) => {
        const info = p.imageinfo?.[0];
        if (!info) return null;

        const title = (p.title || '')
          .replace(/^File:/, '')
          .replace(/\.[^/.]+$/, '')
          .replace(/_/g, ' ');

        // Check file extension on title or url
        if (!p.title?.match(/\.(jpe?g|png|webp)$/i)) return null;

        const url = info.url || info.thumburl || '';
        const thumbUrl = info.thumburl || url;
        if (!thumbUrl) return null;

        const metadata = info.extmetadata || {};
        const description =
          metadata.ObjectName?.value || metadata.ImageDescription?.value || title;
        const cleanDesc = (typeof description === 'string' ? description : title)
          .replace(/<[^>]+>/g, '')
          .slice(0, 150);

        return {
          id: p.pageid,
          title,
          description: cleanDesc,
          url,
          thumbUrl,
          author: metadata.Artist?.value?.replace(/<[^>]+>/g, '') || '文化資料アーカイブ',
          license: metadata.LicenseShortName?.value || 'CC License',
        };
      })
      .filter(Boolean);

    res.json({ images });
  } catch (error) {
    console.error('Image search error:', error);
    res.json({ images: [] });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer();
