/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { EncyclopediaView } from './components/EncyclopediaView';
import { QuizDojo } from './components/QuizDojo';
import { CertificateModal } from './components/CertificateModal';
import { SearchExplorer } from './components/SearchExplorer';
import { sound } from './utils/audio';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('explore');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showRuby, setShowRuby] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isCertificateOpen, setIsCertificateOpen] = useState<boolean>(false);

  // Local storage for kid's persistent learning record
  const [collectedStamps, setCollectedStamps] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nippon_tradition_stamps');
      return saved ? JSON.parse(saved) : ['shogatsu'];
    } catch {
      return ['shogatsu'];
    }
  });

  const [quizScore, setQuizScore] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('nippon_tradition_quiz_score');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('nippon_tradition_stamps', JSON.stringify(collectedStamps));
    } catch {
      // Ignore storage errors
    }
  }, [collectedStamps]);

  useEffect(() => {
    try {
      localStorage.setItem('nippon_tradition_quiz_score', quizScore.toString());
    } catch {
      // Ignore
    }
  }, [quizScore]);

  const handleAddStamp = (id: string) => {
    if (!collectedStamps.includes(id)) {
      setCollectedStamps((prev) => [...prev, id]);
    }
  };

  const handleResetProgress = () => {
    if (window.confirm('これまでに集めたスタンプや得点をリセットしますか？')) {
      setCollectedStamps(['shogatsu']);
      setQuizScore(0);
      sound.playHyoshigi();
    }
  };

  return (
    <div className={`min-h-screen bg-stone-50 text-stone-800 flex flex-col ${!showRuby ? 'no-ruby' : ''}`}>
      {/* 3-Zone Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        showRuby={showRuby}
        setShowRuby={setShowRuby}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        onOpenCertificate={() => setIsCertificateOpen(true)}
        stampCount={collectedStamps.length}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Hero Section shown on Explore or as global banner */}
        {activeTab === 'explore' && (
          <HeroSection
            onStartExplore={() => setActiveTab('explore')}
            onStartSearch={() => setActiveTab('search')}
            onStartQuiz={() => setActiveTab('quiz')}
            stampCount={collectedStamps.length}
            quizScore={quizScore}
            showRuby={showRuby}
          />
        )}

        {/* Tab 1: Encyclopedia View */}
        {activeTab === 'explore' && (
          <EncyclopediaView
            showRuby={showRuby}
            collectedStamps={collectedStamps}
            onAddStamp={handleAddStamp}
            onSearchTradition={(query) => {
              setSearchQuery(query);
              setActiveTab('search');
            }}
          />
        )}

        {/* Tab 2: Google Search & Cultural Images View */}
        {activeTab === 'search' && (
          <SearchExplorer
            initialQuery={searchQuery}
            onClearInitialQuery={() => setSearchQuery('')}
            showRuby={showRuby}
          />
        )}

        {/* Tab 3: Quiz Dojo */}
        {activeTab === 'quiz' && (
          <QuizDojo
            onScoreUpdate={(s) => setQuizScore((prev) => Math.max(prev, s))}
            onAddStamp={handleAddStamp}
            collectedStamps={collectedStamps}
          />
        )}
      </main>

      {/* Printable Certificate Modal */}
      <CertificateModal
        isOpen={isCertificateOpen}
        onClose={() => setIsCertificateOpen(false)}
        stampCount={collectedStamps.length}
        quizScore={quizScore}
        collectedStamps={collectedStamps}
      />

      {/* Clean Educational Footer */}
      <footer className="border-t border-stone-200 bg-white py-8 px-4 sm:px-6 lg:px-8 mt-12 print:hidden">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="flex items-center gap-3">
            <span className="font-bold text-stone-700">にっぽん伝統たんけん隊</span>
            <span>·</span>
            <span>小学校4年生 社会科「地域に受け継がれる伝統と文化」学習支援アプリ</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={handleResetProgress}
              className="text-stone-400 hover:text-red-700 underline transition-colors"
            >
              学習きろくのリセット
            </button>
            <span>·</span>
            <span>Google検索グラウンディング＆文化資料アーカイブ連携</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
