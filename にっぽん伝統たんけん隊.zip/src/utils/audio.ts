/**
 * Web Audio API based traditional Japanese sound effects.
 * Completely local, zero external audio assets required, 100% offline.
 */

class SoundEffects {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  /**
   * Koto (Japanese harp) pluck tone - pentatonic scale note
   */
  playKoto(noteIndex = 0) {
    if (!this.enabled) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const pentatonic = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25]; // C, D, E, G, A, C, D, E
      const freq = pentatonic[noteIndex % pentatonic.length];
      const now = this.ctx.currentTime;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Sharp attack, gentle resonant decay like a plucked string
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      // Slight pitch bend on release like pressing a koto string
      osc.frequency.exponentialRampToValueAtTime(freq * 1.02, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(freq, now + 0.4);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.25, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.6);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  /**
   * Taiko (Japanese drum) strike sound
   */
  playTaiko() {
    if (!this.enabled) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(45, now + 0.25);

      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // Audio fallback
    }
  }

  /**
   * Hyoshigi (wooden clappers) crisp clap
   */
  playHyoshigi() {
    if (!this.enabled) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.04);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch {
      // Fallback
    }
  }

  /**
   * Correct Answer Chime
   */
  playCorrect() {
    if (!this.enabled) return;
    this.playKoto(3);
    setTimeout(() => this.playKoto(5), 110);
    setTimeout(() => this.playKoto(7), 220);
  }

  /**
   * Incorrect Answer Tone
   */
  playWrong() {
    if (!this.enabled) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.setValueAtTime(140, now + 0.12);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // Fallback
    }
  }

  /**
   * Fanfare sound for certificate or quiz completion
   */
  playFanfare() {
    if (!this.enabled) return;
    const notes = [0, 2, 4, 5, 7];
    notes.forEach((n, idx) => {
      setTimeout(() => {
        this.playKoto(n);
        if (idx === notes.length - 1) {
          this.playTaiko();
        }
      }, idx * 130);
    });
  }
}

export const sound = new SoundEffects();
