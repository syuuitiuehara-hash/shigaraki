/**
 * Web Speech API text-to-speech utility for Japanese reading.
 * Completely local, works in all standard modern browsers without external API keys.
 */

class SpeechHelper {
  private synth: SpeechSynthesis | null = null;
  public isSpeaking: boolean = false;
  private onStateChangeListeners: Array<(speaking: boolean) => void> = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public subscribe(listener: (speaking: boolean) => void) {
    this.onStateChangeListeners.push(listener);
    return () => {
      this.onStateChangeListeners = this.onStateChangeListeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.onStateChangeListeners.forEach(l => l(this.isSpeaking));
  }

  /**
   * Speak Japanese text clearly at child-friendly speed
   */
  speak(text: string, onEnd?: () => void) {
    if (!this.synth) return;

    this.stop();

    // Clean ruby markup tags if any
    const cleanText = text.replace(/<rt>.*?<\/rt>/g, '').replace(/<[^>]+>/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ja-JP';
    utterance.rate = 0.95; // slightly relaxed for 4th graders
    utterance.pitch = 1.05;

    // Pick best Japanese voice if available
    const voices = this.synth.getVoices();
    const jaVoice = voices.find(v => v.lang.startsWith('ja') && (v.name.includes('Natural') || v.name.includes('Kyoko') || v.name.includes('Otoya') || v.name.includes('Google')));
    if (jaVoice) {
      utterance.voice = jaVoice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.notify();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.notify();
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.notify();
    };

    this.synth.speak(utterance);
  }

  stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.notify();
    }
  }
}

export const speech = new SpeechHelper();
