import React from 'react';
import { Volume2, VolumeX, Sparkles, Award } from 'lucide-react';
import { sound } from '../utils/audio';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  showRuby: boolean;
  setShowRuby: (show: boolean) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  onOpenCertificate: () => void;
  stampCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  showRuby,
  setShowRuby,
  soundEnabled,
  setSoundEnabled,
  onOpenCertificate,
  stampCount
}) => {
  const navItems = [
    { id: 'explore', label: '伝統ずかん', kana: 'でんとうずかん' },
    { id: 'search', label: 'Google検索', kana: 'ぐーぐるけんさく' },
    { id: 'quiz', label: 'クイズ道場', kana: 'くいずどうじょう' },
  ];

  const handleTabClick = (tabId: string) => {
    sound.playHyoshigi();
    setActiveTab(tabId);
  };

  const handleToggleSound = () => {
    const next = !soundEnabled;
    sound.enabled = next;
    setSoundEnabled(next);
    if (next) sound.playKoto(4);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-amber-900/10 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Brand Wordmark (Single text element) */}
          <button
            onClick={() => handleTabClick('explore')}
            className="flex items-center gap-2.5 text-left focus-visible:outline-hidden group"
          >
            <div className="w-9 h-9 rounded-lg bg-red-700 text-white flex items-center justify-center font-mincho font-bold text-lg shadow-xs group-hover:scale-105 transition-transform">
              伝
            </div>
            <div className="whitespace-nowrap shrink-0">
              <span className="font-mincho text-xl font-bold tracking-tight text-stone-900">
                にっぽん伝統たんけん隊
              </span>
            </div>
          </button>

          {/* Zone 2: Clean single-line text navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleTabClick(item.id)}
                  className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors ${
                    isActive
                      ? 'text-red-700 font-bold'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <span className="block">{item.label}</span>
                  {showRuby && (
                    <span className="block text-[10px] text-stone-400 font-normal leading-none -mt-0.5">
                      {item.kana}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-700 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary action + Accessibility toggles */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Furigana Toggle */}
            <button
              onClick={() => setShowRuby(!showRuby)}
              className={`px-2.5 py-1 text-xs rounded-md border transition-colors whitespace-nowrap shrink-0 ${
                showRuby
                  ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                  : 'bg-stone-100 border-stone-200 text-stone-600 hover:bg-stone-200'
              }`}
              title="ふりがな（ルビ）の表示を切り替えます"
            >
              ふりがな: {showRuby ? 'ON' : 'OFF'}
            </button>

            {/* Sound Toggle */}
            <button
              onClick={handleToggleSound}
              className={`p-1.5 rounded-md border transition-colors ${
                soundEnabled
                  ? 'text-red-700 border-red-200 bg-red-50 hover:bg-red-100'
                  : 'text-stone-400 border-stone-200 bg-stone-50 hover:bg-stone-100'
              }`}
              title={soundEnabled ? '音声をオフにする' : '和の音をオンにする'}
              aria-label="効果音の切り替え"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Primary Action Button */}
            <button
              onClick={() => {
                sound.playFanfare();
                onOpenCertificate();
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 rounded-lg shadow-xs transition-colors whitespace-nowrap shrink-0"
            >
              <Award className="w-4 h-4 text-amber-300" />
              <span>修了しょうじょう</span>
              <span className="bg-red-900/60 px-1.5 py-0.5 rounded text-[11px] tabular-nums font-mono text-amber-200">
                {stampCount}/12
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row (Horizontal Scrollable) */}
        <div className="md:hidden flex items-center gap-2 py-2 overflow-x-auto border-t border-stone-200/60 no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`px-3 py-1 text-xs whitespace-nowrap rounded-md font-medium transition-colors ${
                activeTab === item.id
                  ? 'bg-red-700 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-700'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
