import React, { useState } from 'react';
import { X, Printer, Award, Sparkles, CheckCircle2 } from 'lucide-react';
import { sound } from '../utils/audio';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  stampCount: number;
  quizScore: number;
  collectedStamps: string[];
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  stampCount,
  quizScore,
  collectedStamps
}) => {
  const [studentName, setStudentName] = useState<string>('探検隊員');

  if (!isOpen) return null;

  const handlePrint = () => {
    sound.playHyoshigi();
    window.print();
  };

  const today = new Date();
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative bg-white rounded-3xl border border-stone-200 max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 my-8">
        {/* Modal Controls (Not printed) */}
        <div className="flex items-center justify-between border-b border-stone-100 pb-4 print:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-stone-900 text-lg">修了しょうじょう（認定証）</h3>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>印刷 / PDF保存</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600 hover:bg-stone-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Student Name Input (Not printed) */}
        <div className="print:hidden bg-amber-50 rounded-xl p-3 border border-amber-200 flex items-center gap-3">
          <label className="text-xs font-bold text-amber-900 shrink-0">
            あなたの名前を入力:
          </label>
          <input
            type="text"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
            className="flex-1 px-3 py-1 bg-white border border-amber-300 rounded-md text-sm font-bold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            placeholder="例: たろう / さくら"
            maxLength={15}
          />
        </div>

        {/* Printable Certificate Area */}
        <div
          id="certificate-print-area"
          className="relative bg-amber-50/70 border-8 border-double border-amber-800/80 rounded-2xl p-6 sm:p-10 text-center space-y-6 shadow-inner overflow-hidden"
        >
          {/* Traditional Wagara Corner Accents */}
          <div className="absolute top-2 left-2 text-amber-800/30 font-mincho text-2xl select-none">
            ❖
          </div>
          <div className="absolute top-2 right-2 text-amber-800/30 font-mincho text-2xl select-none">
            ❖
          </div>
          <div className="absolute bottom-2 left-2 text-amber-800/30 font-mincho text-2xl select-none">
            ❖
          </div>
          <div className="absolute bottom-2 right-2 text-amber-800/30 font-mincho text-2xl select-none">
            ❖
          </div>

          <div className="space-y-1">
            <span className="text-xs sm:text-sm font-bold tracking-widest text-amber-900">
              にっぽん伝統たんけん隊
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold font-mincho text-stone-900 tracking-wider">
              修了証書
            </h2>
          </div>

          {/* Student Recipient Name */}
          <div className="border-b-2 border-stone-800 pb-2 max-w-xs mx-auto">
            <span className="text-xl sm:text-2xl font-bold font-mincho text-stone-900">
              {studentName || '伝統探検隊員'} 殿
            </span>
          </div>

          {/* Body Text */}
          <p className="text-stone-800 font-mincho text-sm sm:text-base leading-relaxed max-w-lg mx-auto">
            あなたは、日本に受け継がれる年中行事や伝統工芸、伝統芸能・芸道、伝統食文化について熱心に探検・調べ学習を行い、すぐれた知識を修得しました。
            ここに「伝統ものしり博士」として認定し、その努力をたたえます。
          </p>

          {/* Stamps & Achievements Tally */}
          <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto pt-2">
            <div className="bg-white/80 rounded-xl p-3 border border-amber-800/30 text-center">
              <span className="text-[11px] text-stone-500 font-bold block">獲得スタンプ</span>
              <strong className="text-lg sm:text-xl font-mono text-stone-900">
                {stampCount} 個
              </strong>
            </div>

            <div className="bg-white/80 rounded-xl p-3 border border-amber-800/30 text-center">
              <span className="text-[11px] text-stone-500 font-bold block">クイズ正解</span>
              <strong className="text-lg sm:text-xl font-mono text-red-700">
                {quizScore} 問
              </strong>
            </div>
          </div>

          {/* Footer Date and Red Seal Stamp */}
          <div className="flex items-end justify-between pt-6 border-t border-amber-900/20 max-w-lg mx-auto">
            <div className="text-left space-y-1">
              <div className="text-xs text-stone-600 font-mincho">{dateStr}</div>
              <div className="text-xs font-bold text-stone-900 font-mincho">
                にっぽん伝統文化学習探検隊
              </div>
            </div>

            {/* Red Seal 落款印 */}
            <div className="w-16 h-16 rounded-xl border-2 border-red-700 bg-red-50 text-red-700 flex flex-col items-center justify-center font-mincho font-bold text-xs shadow-xs transform rotate-2">
              <span>伝統探検</span>
              <span>之印</span>
            </div>
          </div>
        </div>

        <div className="text-center print:hidden">
          <p className="text-xs text-stone-500">
            ※「印刷 / PDF保存」ボタンを押すと、おうちのプリンターで印刷したりPDFとして自由研究ノートに貼ることができます。
          </p>
        </div>
      </div>
    </div>
  );
};
