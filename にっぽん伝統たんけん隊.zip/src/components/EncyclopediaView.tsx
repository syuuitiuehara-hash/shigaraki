import React, { useState } from 'react';
import {
  ANNUAL_EVENTS,
  TRADITIONAL_CRAFTS,
  PERFORMING_ARTS,
  FOOD_CULTURE,
  AnnualEvent,
  TraditionalCraft,
  PerformingArt,
  TraditionalFoodCulture
} from '../data/traditions';
import {
  Volume2,
  CheckCircle,
  Sparkles,
  MapPin,
  Calendar,
  Layers,
  Search,
  BookOpen,
  UtensilsCrossed,
  Theater,
  Hammer
} from 'lucide-react';
import { sound } from '../utils/audio';
import { speech } from '../utils/speech';
import { RubyText } from './RubyText';

interface EncyclopediaViewProps {
  showRuby: boolean;
  collectedStamps: string[];
  onAddStamp: (id: string) => void;
  onSearchTradition?: (query: string) => void;
}

type TabCategory = 'events' | 'crafts' | 'arts' | 'food';

export const EncyclopediaView: React.FC<EncyclopediaViewProps> = ({
  showRuby,
  collectedStamps,
  onAddStamp,
  onSearchTradition
}) => {
  const [activeCategory, setActiveCategory] = useState<TabCategory>('events');
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedArtsCategory, setSelectedArtsCategory] = useState<string>('all');
  const [selectedFoodCategory, setSelectedFoodCategory] = useState<string>('all');

  const [selectedEventId, setSelectedEventId] = useState<string>(ANNUAL_EVENTS[0].id);
  const [selectedCraftId, setSelectedCraftId] = useState<string>(TRADITIONAL_CRAFTS[0].id);
  const [selectedArtId, setSelectedArtId] = useState<string>(PERFORMING_ARTS[0].id);
  const [selectedFoodId, setSelectedFoodId] = useState<string>(FOOD_CULTURE[0].id);

  const [isNarrating, setIsNarrating] = useState<boolean>(false);
  const [showAnswer, setShowAnswer] = useState<boolean>(false);

  const selectedEvent = ANNUAL_EVENTS.find((e) => e.id === selectedEventId) || ANNUAL_EVENTS[0];
  const selectedCraft = TRADITIONAL_CRAFTS.find((c) => c.id === selectedCraftId) || TRADITIONAL_CRAFTS[0];
  const selectedArt = PERFORMING_ARTS.find((a) => a.id === selectedArtId) || PERFORMING_ARTS[0];
  const selectedFood = FOOD_CULTURE.find((f) => f.id === selectedFoodId) || FOOD_CULTURE[0];

  const seasons = ['all', '春', '夏', '秋', '冬'];
  const regions = ['all', '東北地方', '関東地方', '中部地方', '近畿地方', '九州地方'];
  const artsCategories = ['all', '舞台芸能', '芸道・くらし'];
  const foodCategories = ['all', '基本の知恵', '発酵と出汁', '季節と行事食'];

  const filteredEvents = ANNUAL_EVENTS.filter(
    (e) => selectedSeason === 'all' || e.season === selectedSeason
  );

  const filteredCrafts = TRADITIONAL_CRAFTS.filter(
    (c) => selectedRegion === 'all' || c.region === selectedRegion
  );

  const filteredArts = PERFORMING_ARTS.filter(
    (a) => selectedArtsCategory === 'all' || a.category === selectedArtsCategory
  );

  const filteredFood = FOOD_CULTURE.filter(
    (f) => selectedFoodCategory === 'all' || f.category === selectedFoodCategory
  );

  const handleReadAloud = (textToRead: string) => {
    if (isNarrating) {
      speech.stop();
      setIsNarrating(false);
    } else {
      setIsNarrating(true);
      speech.speak(textToRead, () => {
        setIsNarrating(false);
      });
    }
  };

  const handleCollectStamp = (id: string) => {
    if (!collectedStamps.includes(id)) {
      sound.playTaiko();
      sound.playCorrect();
      onAddStamp(id);
    }
  };

  const handleTabChange = (cat: TabCategory) => {
    speech.stop();
    setIsNarrating(false);
    setShowAnswer(false);
    if (cat === 'events') sound.playKoto(1);
    if (cat === 'crafts') sound.playKoto(2);
    if (cat === 'arts') sound.playHyoshigi();
    if (cat === 'food') sound.playKoto(3);
    setActiveCategory(cat);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Category Switcher Tabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <h2 className="text-2xl font-bold font-mincho text-stone-900 flex items-center gap-2">
            {activeCategory === 'events' && '年中行事とおまつり図鑑'}
            {activeCategory === 'crafts' && '全国の伝統工芸と職人図鑑'}
            {activeCategory === 'arts' && '伝統芸能・芸道図鑑'}
            {activeCategory === 'food' && 'ユネスコ無形文化遺産・伝統食文化図鑑'}
          </h2>
          <p className="text-sm text-stone-500 mt-0.5">
            {activeCategory === 'events' && '季節ごとの行事と、そこに込められた人々の願いや行事食を学ぼう！'}
            {activeCategory === 'crafts' && '日本全国の自然素材と匠の技が生み出す、ものづくりの結晶！'}
            {activeCategory === 'arts' && '歌舞伎や能・狂言、落語から茶道・華道・書道まで、日本人の心と所作を学ぶ！'}
            {activeCategory === 'food' && '一汁三菜の栄養バランス、出汁とうま味、発酵の知恵、四季折々の旬を味わう！'}
          </p>
        </div>

        {/* 4 Category Switch Buttons */}
        <div className="grid grid-cols-2 sm:flex items-center gap-1.5 p-1.5 bg-stone-100 rounded-xl border border-stone-200">
          <button
            onClick={() => handleTabChange('events')}
            className={`flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors ${
              activeCategory === 'events'
                ? 'bg-red-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>年中行事・まつり</span>
          </button>

          <button
            onClick={() => handleTabChange('crafts')}
            className={`flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors ${
              activeCategory === 'crafts'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Hammer className="w-4 h-4" />
            <span>伝統工芸と職人</span>
          </button>

          <button
            onClick={() => handleTabChange('arts')}
            className={`flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors ${
              activeCategory === 'arts'
                ? 'bg-purple-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <Theater className="w-4 h-4" />
            <span>伝統芸能・芸道</span>
          </button>

          <button
            onClick={() => handleTabChange('food')}
            className={`flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors ${
              activeCategory === 'food'
                ? 'bg-amber-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
            }`}
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span>伝統食文化</span>
          </button>
        </div>
      </div>

      {/* 1. Category View: 年中行事とおまつり */}
      {activeCategory === 'events' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Selector List (4 Cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
              {seasons.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSeason(s)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    selectedSeason === s
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {s === 'all' ? 'すべて' : `${s}の行事`}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {filteredEvents.map((event) => {
                const isSelected = selectedEvent.id === event.id;
                const isStamped = collectedStamps.includes(event.id);

                return (
                  <button
                    key={event.id}
                    onClick={() => {
                      sound.playKoto(2);
                      speech.stop();
                      setIsNarrating(false);
                      setShowAnswer(false);
                      setSelectedEventId(event.id);
                    }}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-red-50/70 border-red-300 ring-2 ring-red-700/20 shadow-xs'
                        : 'bg-white border-stone-200 hover:border-stone-300 hover:bg-stone-50/80'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-stone-500">
                        <span className="font-semibold text-red-700">{event.season}</span>
                        <span>·</span>
                        <span>{event.dateStr}</span>
                      </div>
                      <div className="font-bold text-stone-900 text-base flex items-center gap-2">
                        <RubyText kanji={event.title} kana={event.titleKana} showRuby={showRuby} />
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      {isStamped && (
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shadow-xs" title="スタンプ獲得済み！">
                          済
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right / Stage Details (8 Cols) */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
              <div>
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
                  <span className="px-2 py-0.5 rounded-md bg-red-100 text-red-800 font-bold">
                    {selectedEvent.season}の行事
                  </span>
                  <span>{selectedEvent.dateStr}</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-mincho text-stone-900">
                  <RubyText
                    kanji={selectedEvent.title}
                    kana={selectedEvent.titleKana}
                    showRuby={showRuby}
                  />
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onSearchTradition && (
                  <button
                    onClick={() => onSearchTradition(`${selectedEvent.title} 由来と歴史`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200 transition-colors shadow-2xs"
                    title="Google検索でこの行事の最新情報や写真を調べます"
                  >
                    <Search className="w-3.5 h-3.5 text-red-700" />
                    <span>Googleで調べる</span>
                  </button>
                )}

                <button
                  onClick={() =>
                    handleReadAloud(
                      `${selectedEvent.title}。${selectedEvent.summary}。${selectedEvent.foodMeaning}`
                    )
                  }
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    isNarrating
                      ? 'bg-red-700 text-white border-red-700'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isNarrating ? 'よみあげ中…' : 'こえで聞く'}</span>
                </button>

                <button
                  onClick={() => handleCollectStamp(selectedEvent.id)}
                  disabled={collectedStamps.includes(selectedEvent.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                    collectedStamps.includes(selectedEvent.id)
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-500 hover:bg-amber-600 text-stone-950 border-amber-500 shadow-xs'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>
                    {collectedStamps.includes(selectedEvent.id)
                      ? 'スタンプ済み'
                      : '学んだ！スタンプ'}
                  </span>
                </button>
              </div>
            </div>

            {selectedEvent.image && (
              <div className="relative rounded-xl overflow-hidden border border-stone-200 shadow-xs max-h-72">
                <img
                  src={selectedEvent.image}
                  alt={selectedEvent.title}
                  className="w-full h-64 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            <div className="bg-amber-50/60 rounded-xl p-4 border border-amber-200/80">
              <h4 className="text-xs font-bold text-amber-900 uppercase mb-1 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                どんな行事？
              </h4>
              <p className="text-stone-800 text-sm sm:text-base leading-relaxed">
                {selectedEvent.summary}
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-red-700" />
                行事の風習・ならわし
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedEvent.customs.map((custom, idx) => {
                  const parts = custom.split(':');
                  return (
                    <div key={idx} className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
                      <div className="text-xs font-bold text-red-700 mb-1">{parts[0]}</div>
                      <p className="text-xs text-stone-600 leading-relaxed">{parts[1] || parts[0]}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-red-50/50 rounded-xl p-4 border border-red-200/60 space-y-2">
              <div className="text-xs font-bold text-red-900 flex items-center gap-1.5">
                <UtensilsCrossed className="w-4 h-4 text-red-700" />
                <span>食べるもの・行事食: {selectedEvent.food}</span>
              </div>
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                {selectedEvent.foodMeaning}
              </p>
            </div>

            <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-2">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-stone-700">クイズで確かめよう！</div>
                <button
                  onClick={() => {
                    sound.playHyoshigi();
                    setShowAnswer(!showAnswer);
                  }}
                  className="text-xs text-red-700 hover:text-red-800 font-bold underline"
                >
                  {showAnswer ? 'こたえをかくす' : 'こたえを見る'}
                </button>
              </div>
              <p className="text-xs sm:text-sm text-stone-800 font-medium">
                {selectedEvent.quizQuestion}
              </p>
              {showAnswer && (
                <div className="pt-2 border-t border-stone-200 text-xs sm:text-sm text-red-700 font-bold">
                  こたえ：{selectedEvent.quizAnswer}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. Category View: 伝統工芸と職人の技 */}
      {activeCategory === 'crafts' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Craft Selector List */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto">
              {regions.map((r) => (
                <button
                  key={r}
                  onClick={() => setSelectedRegion(r)}
                  className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    selectedRegion === r
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {r === 'all' ? '全国' : r.replace('地方', '')}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {filteredCrafts.map((craft) => {
                const isSelected = selectedCraft.id === craft.id;
                const isStamped = collectedStamps.includes(craft.id);

                return (
                  <button
                    key={craft.id}
                    onClick={() => {
                      sound.playKoto(3);
                      speech.stop();
                      setIsNarrating(false);
                      setSelectedCraftId(craft.id);
                    }}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-blue-50/70 border-blue-300 ring-2 ring-blue-700/20 shadow-xs'
                        : 'bg-white border-stone-200 hover:border-stone-300 hover:bg-stone-50/80'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-stone-500">
                        <MapPin className="w-3 h-3 text-stone-400" />
                        <span>{craft.prefecture}</span>
                      </div>
                      <div className="font-bold text-stone-900 text-base">
                        <RubyText kanji={craft.name} kana={craft.nameKana} showRuby={showRuby} />
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isStamped && (
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shadow-xs">
                          済
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right / Craft Stage Details */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
              <div>
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
                  <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 font-bold">
                    {selectedCraft.region}
                  </span>
                  <span className="flex items-center gap-1 text-stone-600">
                    <MapPin className="w-3 h-3" />
                    {selectedCraft.prefecture}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-mincho text-stone-900">
                  <RubyText
                    kanji={selectedCraft.name}
                    kana={selectedCraft.nameKana}
                    showRuby={showRuby}
                  />
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onSearchTradition && (
                  <button
                    onClick={() => onSearchTradition(`${selectedCraft.name} 特徴と歴史`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200 transition-colors shadow-2xs"
                    title="Google検索でこの工芸品の写真や最新情報を調べます"
                  >
                    <Search className="w-3.5 h-3.5 text-blue-700" />
                    <span>Googleで調べる</span>
                  </button>
                )}

                <button
                  onClick={() =>
                    handleReadAloud(
                      `${selectedCraft.name}。${selectedCraft.feature}。職人の秘密：${selectedCraft.secret}`
                    )
                  }
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    isNarrating
                      ? 'bg-blue-700 text-white border-blue-700'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isNarrating ? 'よみあげ中…' : 'こえで聞く'}</span>
                </button>

                <button
                  onClick={() => handleCollectStamp(selectedCraft.id)}
                  disabled={collectedStamps.includes(selectedCraft.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                    collectedStamps.includes(selectedCraft.id)
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-500 hover:bg-amber-600 text-stone-950 border-amber-500 shadow-xs'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>
                    {collectedStamps.includes(selectedCraft.id)
                      ? 'スタンプ済み'
                      : '学んだ！スタンプ'}
                  </span>
                </button>
              </div>
            </div>

            {/* Real Craft Visual Showcase */}
            <div className="relative rounded-xl overflow-hidden border border-stone-200 shadow-xs max-h-80">
              <img
                src={selectedCraft.image}
                alt={selectedCraft.name}
                className="w-full h-72 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white text-xs sm:text-sm font-medium">
                職人の魂と技が宿る「{selectedCraft.name}」（{selectedCraft.prefecture}）
              </div>
            </div>

            <div className="bg-blue-50/60 rounded-xl p-4 border border-blue-200/80">
              <h4 className="text-xs font-bold text-blue-900 uppercase mb-1 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-blue-700" />
                どんな特徴の工芸品？
              </h4>
              <p className="text-stone-800 text-sm sm:text-base leading-relaxed">
                {selectedCraft.feature}
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-blue-700" />
                職人さんの技・4つのステップ
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedCraft.steps.map((st, i) => (
                  <div key={i} className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
                    <div className="text-xs font-bold text-red-700 mb-1">{st.title}</div>
                    <p className="text-xs text-stone-600 leading-relaxed">{st.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-stone-50 rounded-xl p-4 border border-stone-200 space-y-1.5">
                <div className="text-xs font-bold text-stone-600">おもな材料（自然の恵み）</div>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedCraft.materials.map((m, idx) => (
                    <span
                      key={idx}
                      className="text-xs bg-white px-2.5 py-1 rounded-md border border-stone-200 text-stone-700 font-medium"
                    >
                      {m}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 space-y-1.5">
                <div className="text-xs font-bold text-amber-900 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  職人の知恵・ひみつ！
                </div>
                <p className="text-xs text-amber-950 leading-relaxed">
                  {selectedCraft.secret}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. Category View: 伝統芸能、芸道 */}
      {activeCategory === 'arts' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Performing Arts Selector List */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg">
              {artsCategories.map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedArtsCategory(c)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    selectedArtsCategory === c
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {c === 'all' ? 'すべて' : c}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {filteredArts.map((art) => {
                const isSelected = selectedArt.id === art.id;
                const isStamped = collectedStamps.includes(art.id);

                return (
                  <button
                    key={art.id}
                    onClick={() => {
                      sound.playHyoshigi();
                      speech.stop();
                      setIsNarrating(false);
                      setSelectedArtId(art.id);
                    }}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-purple-50/70 border-purple-300 ring-2 ring-purple-700/20 shadow-xs'
                        : 'bg-white border-stone-200 hover:border-stone-300 hover:bg-stone-50/80'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-stone-500">
                        <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 font-bold">
                          {art.category}
                        </span>
                      </div>
                      <div className="font-bold text-stone-900 text-base">
                        <RubyText kanji={art.name} kana={art.nameKana} showRuby={showRuby} />
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isStamped && (
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shadow-xs">
                          済
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right / Performing Arts Stage Details */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
              <div>
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
                  <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 font-bold">
                    {selectedArt.category}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-mincho text-stone-900">
                  <RubyText
                    kanji={selectedArt.name}
                    kana={selectedArt.nameKana}
                    showRuby={showRuby}
                  />
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onSearchTradition && (
                  <button
                    onClick={() => onSearchTradition(`${selectedArt.name} 特徴と歴史`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200 transition-colors shadow-2xs"
                    title="Google検索でこの伝統芸能の写真や最新情報を調べます"
                  >
                    <Search className="w-3.5 h-3.5 text-purple-700" />
                    <span>Googleで調べる</span>
                  </button>
                )}

                <button
                  onClick={() =>
                    handleReadAloud(
                      `${selectedArt.name}。${selectedArt.feature}。ひみつ：${selectedArt.secret}`
                    )
                  }
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    isNarrating
                      ? 'bg-purple-700 text-white border-purple-700'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isNarrating ? 'よみあげ中…' : 'こえで聞く'}</span>
                </button>

                <button
                  onClick={() => handleCollectStamp(selectedArt.id)}
                  disabled={collectedStamps.includes(selectedArt.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                    collectedStamps.includes(selectedArt.id)
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-500 hover:bg-amber-600 text-stone-950 border-amber-500 shadow-xs'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>
                    {collectedStamps.includes(selectedArt.id)
                      ? 'スタンプ済み'
                      : '学んだ！スタンプ'}
                  </span>
                </button>
              </div>
            </div>

            {/* Visual Showcase for Performing Art */}
            <div className="relative rounded-xl overflow-hidden border border-stone-200 shadow-xs max-h-80">
              <img
                src={selectedArt.image}
                alt={selectedArt.name}
                className="w-full h-72 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white text-xs sm:text-sm font-medium">
                日本が誇る表現文化「{selectedArt.name}」
              </div>
            </div>

            <div className="bg-purple-50/60 rounded-xl p-4 border border-purple-200/80">
              <h4 className="text-xs font-bold text-purple-900 uppercase mb-1 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-purple-700" />
                どんな魅力と歴史があるの？
              </h4>
              <p className="text-stone-800 text-sm sm:text-base leading-relaxed mb-2">
                {selectedArt.feature}
              </p>
              <div className="text-xs text-purple-900 bg-purple-100/60 rounded-lg p-2.5">
                <span className="font-bold">歴史のはじまり：</span> {selectedArt.history}
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-purple-700" />
                ここに注目！伝統の型と見どころ
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedArt.elements.map((elem, i) => (
                  <div key={i} className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
                    <div className="text-xs font-bold text-purple-800 mb-1">{elem.title}</div>
                    <p className="text-xs text-stone-600 leading-relaxed">{elem.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 space-y-1.5">
              <div className="text-xs font-bold text-amber-900 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                知ってる？伝統芸能・芸道のひみつ！
              </div>
              <p className="text-xs sm:text-sm text-amber-950 leading-relaxed">
                {selectedArt.secret}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 4. Category View: 伝統食文化 */}
      {activeCategory === 'food' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Food Culture Selector List */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg overflow-x-auto">
              {foodCategories.map((c) => (
                <button
                  key={c}
                  onClick={() => setSelectedFoodCategory(c)}
                  className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    selectedFoodCategory === c
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {c === 'all' ? 'すべて' : c}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
              {filteredFood.map((food) => {
                const isSelected = selectedFood.id === food.id;
                const isStamped = collectedStamps.includes(food.id);

                return (
                  <button
                    key={food.id}
                    onClick={() => {
                      sound.playKoto(3);
                      speech.stop();
                      setIsNarrating(false);
                      setSelectedFoodId(food.id);
                    }}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-700/20 shadow-xs'
                        : 'bg-white border-stone-200 hover:border-stone-300 hover:bg-stone-50/80'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs text-stone-500">
                        <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold">
                          {food.category}
                        </span>
                      </div>
                      <div className="font-bold text-stone-900 text-base">
                        <RubyText kanji={food.title} kana={food.titleKana} showRuby={showRuby} />
                      </div>
                    </div>

                    <div className="shrink-0">
                      {isStamped && (
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shadow-xs">
                          済
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right / Food Culture Stage Details */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
              <div>
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
                  <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-bold">
                    {selectedFood.category}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-bold font-mincho text-stone-900">
                  <RubyText
                    kanji={selectedFood.title}
                    kana={selectedFood.titleKana}
                    showRuby={showRuby}
                  />
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onSearchTradition && (
                  <button
                    onClick={() => onSearchTradition(`${selectedFood.title} 和食の知恵`)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200 transition-colors shadow-2xs"
                    title="Google検索でこの食文化の写真や最新情報を調べます"
                  >
                    <Search className="w-3.5 h-3.5 text-amber-800" />
                    <span>Googleで調べる</span>
                  </button>
                )}

                <button
                  onClick={() =>
                    handleReadAloud(
                      `${selectedFood.title}。${selectedFood.summary}。知恵：${selectedFood.wisdom}`
                    )
                  }
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                    isNarrating
                      ? 'bg-amber-700 text-white border-amber-700'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isNarrating ? 'よみあげ中…' : 'こえで聞く'}</span>
                </button>

                <button
                  onClick={() => handleCollectStamp(selectedFood.id)}
                  disabled={collectedStamps.includes(selectedFood.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                    collectedStamps.includes(selectedFood.id)
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-amber-500 hover:bg-amber-600 text-stone-950 border-amber-500 shadow-xs'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>
                    {collectedStamps.includes(selectedFood.id)
                      ? 'スタンプ済み'
                      : '学んだ！スタンプ'}
                  </span>
                </button>
              </div>
            </div>

            {/* Visual Showcase for Food Culture */}
            <div className="relative rounded-xl overflow-hidden border border-stone-200 shadow-xs max-h-80">
              <img
                src={selectedFood.image}
                alt={selectedFood.title}
                className="w-full h-72 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white text-xs sm:text-sm font-medium">
                ユネスコ無形文化遺産・日本の食の知恵「{selectedFood.title}」
              </div>
            </div>

            <div className="bg-amber-50/60 rounded-xl p-4 border border-amber-200/80">
              <h4 className="text-xs font-bold text-amber-900 uppercase mb-1 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                食に込められた知恵と精神
              </h4>
              <p className="text-stone-800 text-sm sm:text-base leading-relaxed mb-2">
                {selectedFood.summary}
              </p>
              <div className="text-xs text-amber-900 bg-amber-100/70 rounded-lg p-2.5">
                <span className="font-bold">先人の知恵：</span> {selectedFood.wisdom}
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-800" />
                知っておきたい！日本の食文化のポイント
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedFood.points.map((pt, i) => (
                  <div key={i} className="bg-stone-50 rounded-xl p-3.5 border border-stone-200">
                    <div className="text-xs font-bold text-amber-800 mb-1">{pt.title}</div>
                    <p className="text-xs text-stone-600 leading-relaxed">{pt.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-200 space-y-1.5">
              <div className="text-xs font-bold text-emerald-900 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                食のひみつ・豆知識！
              </div>
              <p className="text-xs sm:text-sm text-emerald-950 leading-relaxed">
                {selectedFood.secret}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
