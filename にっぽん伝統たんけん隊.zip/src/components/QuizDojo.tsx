import React, { useState } from 'react';
import { TRADITION_QUIZZES, QuizItem } from '../data/traditions';
import { sound } from '../utils/audio';
import { speech } from '../utils/speech';
import { CheckCircle2, XCircle, HelpCircle, Trophy, RotateCcw, Volume2, Sparkles, Award } from 'lucide-react';

interface QuizDojoProps {
  onScoreUpdate: (score: number) => void;
  onAddStamp: (id: string) => void;
  collectedStamps: string[];
}

export const QuizDojo: React.FC<QuizDojoProps> = ({
  onScoreUpdate,
  onAddStamp,
  collectedStamps
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState<boolean>(false);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const currentQuiz: QuizItem = TRADITION_QUIZZES[currentIdx];

  const handleSelectOption = (idx: number) => {
    if (showAnswer) return;

    setSelectedOption(idx);
    setShowAnswer(true);

    if (idx === currentQuiz.answerIndex) {
      sound.playHyoshigi();
      sound.playCorrect();
      const nextCount = correctCount + 1;
      setCorrectCount(nextCount);
      onScoreUpdate(nextCount);
    } else {
      sound.playWrong();
    }
  };

  const handleNext = () => {
    sound.playKoto(1);
    setShowHint(false);
    setShowAnswer(false);
    setSelectedOption(null);

    if (currentIdx + 1 < TRADITION_QUIZZES.length) {
      setCurrentIdx(currentIdx + 1);
    } else {
      setIsFinished(true);
      sound.playFanfare();
      onAddStamp('quiz_master');
    }
  };

  const handleRestart = () => {
    sound.playTaiko();
    setCurrentIdx(0);
    setSelectedOption(null);
    setShowAnswer(false);
    setShowHint(false);
    setCorrectCount(0);
    setIsFinished(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
        <div>
          <h2 className="text-2xl font-bold font-mincho text-stone-900 flex items-center gap-2">
            <span>伝統ものしりクイズ道場</span>
            <span className="text-xs bg-amber-100 text-amber-900 font-bold px-2.5 py-0.5 rounded-full">
              小学4年社会科対応
            </span>
          </h2>
          <p className="text-sm text-stone-500 mt-1">
            全国の行事や工芸、おせち料理の知恵を、三択・四択クイズでマスターしよう！
          </p>
        </div>

        {!isFinished && (
          <div className="flex items-center gap-3 bg-stone-50 px-4 py-2 rounded-xl border border-stone-200">
            <span className="text-xs text-stone-500 font-medium">第 {currentIdx + 1} 問 / 全 {TRADITION_QUIZZES.length} 問</span>
            <span className="text-sm font-bold text-red-700 font-mono tabular-nums">
              正解: {correctCount} 問
            </span>
          </div>
        )}
      </div>

      {!isFinished ? (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-10 shadow-sm space-y-6">
          {/* Progress Bar */}
          <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-red-700 h-2.5 rounded-full transition-all duration-300"
              style={{
                width: `${((currentIdx + 1) / TRADITION_QUIZZES.length) * 100}%`
              }}
            />
          </div>

          {/* Category Tag & Read Aloud */}
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-md text-xs font-bold bg-amber-100 text-amber-900">
              {currentQuiz.category}
            </span>
            <button
              onClick={() => speech.speak(currentQuiz.question)}
              className="flex items-center gap-1.5 px-3 py-1 text-xs text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>もんだいをきく</span>
            </button>
          </div>

          {/* Question Text */}
          <h3 className="text-xl sm:text-2xl font-bold font-mincho text-stone-900 leading-snug">
            {currentQuiz.question}
          </h3>

          {/* Hint Section */}
          <div>
            {!showHint ? (
              <button
                onClick={() => {
                  sound.playKoto(4);
                  setShowHint(true);
                }}
                className="flex items-center gap-1.5 text-xs text-amber-700 hover:text-amber-800 font-semibold"
              >
                <HelpCircle className="w-4 h-4" />
                <span>ヒントをみる</span>
              </button>
            ) : (
              <div className="bg-amber-50 rounded-xl p-3 border border-amber-200 text-xs sm:text-sm text-amber-950 flex items-start gap-2 animate-fade-in">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span><strong>ヒント:</strong> {currentQuiz.hint}</span>
              </div>
            )}
          </div>

          {/* 4 Options Grid */}
          <div className="space-y-3 pt-2">
            {currentQuiz.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isAnswer = currentQuiz.answerIndex === idx;

              let btnStyle = 'bg-stone-50 border-stone-200 hover:border-amber-400 hover:bg-amber-50/40 text-stone-800';

              if (showAnswer) {
                if (isAnswer) {
                  btnStyle = 'bg-emerald-100 border-emerald-500 text-emerald-950 ring-2 ring-emerald-400 font-bold';
                } else if (isSelected && !isAnswer) {
                  btnStyle = 'bg-red-50 border-red-400 text-red-950';
                } else {
                  btnStyle = 'bg-stone-50 border-stone-200 opacity-60 text-stone-400';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={showAnswer}
                  className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center justify-between gap-4 ${btnStyle}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-stone-200/80 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span className="text-sm sm:text-base">{opt}</span>
                  </div>

                  {showAnswer && isAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  )}
                  {showAnswer && isSelected && !isAnswer && (
                    <XCircle className="w-5 h-5 text-red-500 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box when answered */}
          {showAnswer && (
            <div className="space-y-4 pt-4 border-t border-stone-100 animate-fade-in">
              <div className={`p-4 rounded-2xl border ${
                selectedOption === currentQuiz.answerIndex
                  ? 'bg-emerald-50 border-emerald-200'
                  : 'bg-red-50 border-red-200'
              }`}>
                <div className="flex items-center gap-2 font-bold mb-1.5 text-sm">
                  {selectedOption === currentQuiz.answerIndex ? (
                    <span className="text-emerald-700 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" /> だいせいかい！
                    </span>
                  ) : (
                    <span className="text-red-700 flex items-center gap-1.5">
                      <XCircle className="w-4 h-4" /> おしい！正解は「{currentQuiz.options[currentQuiz.answerIndex]}」だよ
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-stone-800 leading-relaxed">
                  {currentQuiz.explanation}
                </p>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleNext}
                  className="px-6 py-2.5 rounded-xl bg-red-700 hover:bg-red-800 text-white font-bold text-sm shadow-md transition-all active:scale-95"
                >
                  {currentIdx + 1 === TRADITION_QUIZZES.length ? '結果をみる！' : '次の問題へ →'}
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Quiz Finished Result Screen */
        <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 text-center shadow-lg space-y-6">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-amber-400 text-stone-950 flex items-center justify-center text-4xl shadow-md animate-bounce">
            <Trophy className="w-10 h-10 text-stone-950" />
          </div>

          <div className="space-y-2">
            <h3 className="text-3xl font-bold font-mincho text-stone-900">
              クイズ道場 修了！
            </h3>
            <p className="text-stone-600 text-base">
              あなたのスコア: <strong className="text-3xl font-bold text-red-700 font-mono tabular-nums">{correctCount}</strong> / {TRADITION_QUIZZES.length} 問正解！
            </p>
          </div>

          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 max-w-md mx-auto text-sm">
            {correctCount === 15 ? (
              <span className="font-bold text-amber-900">
                🎉 すばらしい！全問正解！きみはまさに「伝統ものしり超人」だ！
              </span>
            ) : correctCount >= 10 ? (
              <span className="font-bold text-amber-900">
                ✨ 合格！日本の伝統についてとてもよく学べています！
              </span>
            ) : (
              <span className="font-bold text-stone-700">
                👏 よく挑戦しました！図鑑をもう一度読んで再挑戦してみよう！
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={handleRestart}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-sm transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              <span>もう一度チャレンジ</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
