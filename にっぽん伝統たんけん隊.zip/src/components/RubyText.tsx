import React from 'react';

interface RubyTextProps {
  kanji: string;
  kana: string;
  showRuby?: boolean;
  className?: string;
}

/**
 * Elementary school friendly ruby display component
 * Automatically toggles between ruby and plain text based on user preference.
 */
export const RubyText: React.FC<RubyTextProps> = ({
  kanji,
  kana,
  showRuby = true,
  className = ''
}) => {
  if (!showRuby) {
    return <span className={className}>{kanji}</span>;
  }

  return (
    <ruby className={`inline-ruby ${className}`}>
      {kanji}
      <rt className="text-[10px] select-none text-stone-500 font-normal block leading-tight">
        {kana}
      </rt>
    </ruby>
  );
};
