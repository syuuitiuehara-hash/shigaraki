import React from 'react';
import { BookOpen, Sparkles, Trophy, Compass, CheckCircle2 } from 'lucide-react';
import { sound } from '../utils/audio';

interface HeroSectionProps {
  onStartExplore: () => void;
  onStartQuiz: () => void;
  onStartSearch: () => void;
  stampCount: number;
  quizScore: number;
  showRuby: boolean;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartExplore,
  onStartQuiz,
  onStartSearch,
  stampCount,
  quizScore,
  showRuby
}) => {
  // Calculate student badge rank
  const getRank = () => {
    const totalPoints = stampCount * 10 + quizScore * 6;
    if (totalPoints >= 120) return { title: '伝統ものしり名誉博士', color: 'text-amber-700 bg-amber-100 border-amber-300' };
    if (totalPoints >= 60) return { title: '伝統上級マスター', color: 'text-purple-700 bg-purple-100 border-purple-300' };
    if (totalPoints >= 20) return { title: '伝統たんけん隊員', color: 'text-blue-700 bg-blue-100 border-blue-300' };
    return { title: '伝統みならい隊員', color: 'text-stone-700 bg-stone-100 border-stone-200' };
  };

  const rank = getRank();

  return (
    <section className="relative overflow-hidden bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Mission Description for 4th Graders */}
          <div className="lg:col-span-7 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-900 border border-amber-200">
              <Compass className="w-3.5 h-3.5 text-amber-800" />
              <span>小学4年生 社会科単元対応「地域に受け継がれる伝統と文化」</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-mincho text-stone-900 tracking-tight leading-tight text-balance">
              日本の伝統を
              <span className="text-red-700 inline-block px-1">たんけん</span>
              しよう！
            </h1>

            <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-2xl">
              昔から大切に受け継がれてきた「年中行事やおまつり」「伝統工芸」「伝統芸能・芸道」「伝統食文化」。
              図鑑を読んだり、Google検索で全国の最新情報や実物写真を調べたり、クイズに挑戦して<strong className="text-stone-900 font-semibold">「伝統ものしり博士」</strong>を目指そう！
            </p>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => {
                  sound.playKoto(0);
                  onStartExplore();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-red-700 hover:bg-red-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all transform active:scale-98"
              >
                <BookOpen className="w-4 h-4 text-amber-200" />
                <span>図鑑（ずかん）をひらく</span>
              </button>

              <button
                onClick={() => {
                  sound.playKoto(2);
                  onStartSearch();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all transform active:scale-98"
              >
                <Sparkles className="w-4 h-4 text-blue-200" />
                <span>Googleで調べる</span>
              </button>

              <button
                onClick={() => {
                  sound.playTaiko();
                  onStartQuiz();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-sm shadow-md hover:shadow-lg transition-all transform active:scale-98"
              >
                <Trophy className="w-4 h-4 text-stone-950" />
                <span>クイズ道場に挑む</span>
              </button>
            </div>
          </div>

          {/* Right Column: Hero Illustration Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-amber-900/10 shadow-lg bg-stone-100 group">
              <img
                src="/src/assets/images/hero_japan_tradition_1792678261598.jpg"
                alt="日本の伝統文化（富士山、五重塔、鯉のぼり、伝統工芸）"
                className="w-full h-64 sm:h-72 lg:h-80 object-cover transform group-hover:scale-102 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent flex items-end p-4">
                <div className="text-white text-xs sm:text-sm font-medium">
                  富士山・五重塔・鯉のぼり・職人の技が息づく町並み
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3-Item Progress Ticker Strip */}
        <div className="mt-8 pt-6 border-t border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-base">
              印
            </div>
            <div>
              <div className="text-xs text-stone-500 font-medium">集めたスタンプ</div>
              <div className="text-lg font-bold text-stone-900 font-mono tabular-nums">
                {stampCount} <span className="text-xs font-normal text-stone-500">/ 24こ</span>
              </div>
            </div>
          </div>

          <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-100 text-red-800 flex items-center justify-center font-bold text-base">
              問
            </div>
            <div>
              <div className="text-xs text-stone-500 font-medium">クイズ正解数</div>
              <div className="text-lg font-bold text-stone-900 font-mono tabular-nums">
                {quizScore} <span className="text-xs font-normal text-stone-500">/ 15問</span>
              </div>
            </div>
          </div>

          <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-base">
              位
            </div>
            <div className="truncate">
              <div className="text-xs text-stone-500 font-medium">現在のしょうごう</div>
              <div className="text-xs sm:text-sm font-bold text-purple-900 truncate">
                {rank.title}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
