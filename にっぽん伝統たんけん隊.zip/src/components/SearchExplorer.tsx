import React, { useState, useEffect } from 'react';
import { Search, Globe, Image as ImageIcon, ExternalLink, Sparkles, Loader2, Volume2, BookOpen, AlertCircle, Maximize2, X, Download } from 'lucide-react';
import { sound } from '../utils/audio';
import { speech } from '../utils/speech';

interface SearchResult {
  query: string;
  answer: string;
  sources: { title: string; url: string }[];
}

interface ImageItem {
  id: number;
  title: string;
  description: string;
  url: string;
  thumbUrl: string;
  author: string;
  license: string;
}

interface SearchExplorerProps {
  initialQuery?: string;
  onClearInitialQuery?: () => void;
  showRuby: boolean;
}

export const SearchExplorer: React.FC<SearchExplorerProps> = ({
  initialQuery = '',
  onClearInitialQuery,
  showRuby
}) => {
  const [searchTerm, setSearchTerm] = useState<string>(initialQuery || '輪島塗 漆器');
  const [activeSubTab, setActiveSubTab] = useState<'answer' | 'images'>('answer');
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingImages, setLoadingImages] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SearchResult | null>(null);
  const [images, setImages] = useState<ImageItem[]>([]);
  const [selectedModalImage, setSelectedModalImage] = useState<ImageItem | null>(null);
  const [isNarrating, setIsNarrating] = useState<boolean>(false);

  // Recommended search keywords for 4th graders
  const popularKeywords = [
    { label: '南部鉄器の鉄瓶', query: '南部鉄器 盛岡 鉄瓶の特徴と作り方' },
    { label: '西陣織の先染め', query: '西陣織 京都 先染め紋織物の歴史' },
    { label: '美濃和紙の手漉き', query: '美濃和紙 岐阜 手漉き和紙の特徴' },
    { label: '有田焼の白磁', query: '有田焼 伊万里焼 佐賀 磁器の特徴' },
    { label: '箱根寄木細工の秘密箱', query: '箱根寄木細工 からくり箱の仕組み' },
    { label: '歌舞伎の見得と隈取', query: '歌舞伎 見得と隈取の意味' },
    { label: '能面の表情と狂言', query: '能面 狂言 ユネスコ無形文化遺産' },
    { label: '落語の扇子と手ぬぐい', query: '落語 扇子と手ぬぐいの見立て技' },
    { label: '茶道の一期一会', query: '茶道 千利休 わび茶と一期一会' },
    { label: '和食の一汁三菜', query: '和食 一汁三菜 栄養バランスの知恵' },
    { label: '出汁のうま味の秘密', query: '和食 出汁 昆布と鰹節のうま味相乗効果' },
    { label: '日本の発酵と麹菌', query: '日本 発酵食品 麹菌の力と健康' },
  ];

  // Perform search
  const performSearch = async (queryToSearch: string) => {
    if (!queryToSearch.trim()) return;

    sound.playHyoshigi();
    setLoading(true);
    setLoadingImages(true);
    setError(null);
    speech.stop();
    setIsNarrating(false);

    try {
      // 1. Fetch Google Search Grounding with Gemini
      const searchPromise = fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryToSearch }),
      }).then(async (res) => {
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || '検索に失敗しました');
        }
        return res.json();
      });

      // 2. Fetch real photos of the craft/tradition
      const imagePromise = fetch(`/api/images?q=${encodeURIComponent(queryToSearch)}`)
        .then((res) => (res.ok ? res.json() : { images: [] }))
        .catch(() => ({ images: [] }));

      const [searchData, imageData] = await Promise.all([searchPromise, imagePromise]);

      setResult(searchData);
      setImages(imageData.images || []);
      sound.playKoto(3);
    } catch (err: any) {
      console.error('Search error:', err);
      setError(err.message || '情報の取得中に問題が発生しました。');
      sound.playWrong();
    } finally {
      setLoading(false);
      setLoadingImages(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setSearchTerm(initialQuery);
      performSearch(initialQuery);
      if (onClearInitialQuery) onClearInitialQuery();
    } else if (!result) {
      performSearch('輪島塗 職人の工程と歴史');
    }
  }, [initialQuery]);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(searchTerm);
  };

  const handleReadAloud = (text: string) => {
    if (isNarrating) {
      speech.stop();
      setIsNarrating(false);
    } else {
      setIsNarrating(true);
      speech.speak(text, () => setIsNarrating(false));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="border-b border-stone-200 pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold font-mincho text-stone-900 flex items-center gap-2">
              <span>Google連動 伝統しらべ学習ナビ</span>
              <span className="text-xs bg-red-100 text-red-800 font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Globe className="w-3 h-3 text-red-700" />
                Google検索連動
              </span>
            </h2>
            <p className="text-sm text-stone-500 mt-1">
              Google検索の最新・確実なウェブ情報と、本物の文化財写真をリアルタイムで調べて学習できます。
            </p>
          </div>
        </div>

        {/* Search Input Bar */}
        <form onSubmit={handleFormSubmit} className="mt-5 relative max-w-3xl">
          <div className="relative flex items-center">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="調べたい伝統行事・工芸・お祭り・和食を入力（例: ねぶた祭り、江戸切子の色）"
              className="w-full pl-11 pr-28 py-3.5 bg-white border-2 border-stone-300 rounded-2xl text-stone-900 text-sm sm:text-base font-medium placeholder-stone-400 focus:outline-hidden focus:border-red-700 focus:ring-4 focus:ring-red-700/10 shadow-xs"
            />
            <Search className="w-5 h-5 text-stone-400 absolute left-4 pointer-events-none" />
            <button
              type="submit"
              disabled={loading}
              className="absolute right-2 px-5 py-2 rounded-xl bg-red-700 hover:bg-red-800 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors flex items-center gap-1.5 active:scale-98 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>検索中…</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4" />
                  <span>Googleで探す</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Recommended Chips */}
        <div className="mt-3 flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          <span className="text-xs font-bold text-stone-500 shrink-0">人気の検索:</span>
          {popularKeywords.map((kw, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setSearchTerm(kw.query);
                performSearch(kw.query);
              }}
              className="text-xs bg-stone-100 hover:bg-stone-200 text-stone-700 font-medium px-2.5 py-1 rounded-md whitespace-nowrap transition-colors"
            >
              {kw.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sub Tabs and Direct Google Links */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playKoto(1);
              setActiveSubTab('answer');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-sm font-bold border-b-2 transition-colors ${
              activeSubTab === 'answer'
                ? 'border-red-700 text-red-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>調べ学習まとめ解説</span>
          </button>

          <button
            onClick={() => {
              sound.playKoto(2);
              setActiveSubTab('images');
            }}
            className={`flex items-center gap-2 py-3 px-4 text-sm font-bold border-b-2 transition-colors ${
              activeSubTab === 'images'
                ? 'border-red-700 text-red-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>実物写真ギャラリー ({images.length}枚)</span>
          </button>
        </div>

        {/* Direct Google External Search Links (Always work 100% without keys or GAS) */}
        <div className="flex items-center gap-2">
          <a
            href={`https://www.google.com/search?q=${encodeURIComponent(searchTerm || '日本の伝統')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
            title="Google検索を直接新しいタブで開く"
          >
            <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
            <span>Googleウェブ検索 ↗</span>
          </a>

          <a
            href={`https://www.google.com/search?tbm=isch&q=${encodeURIComponent(searchTerm || '日本の伝統')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
            title="Google画像検索を直接新しいタブで開く"
          >
            <ImageIcon className="w-3.5 h-3.5 text-red-600" />
            <span>Google画像検索 ↗</span>
          </a>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-red-800 text-sm">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold">検索エラー</div>
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="py-16 text-center space-y-4">
          <Loader2 className="w-10 h-10 text-red-700 animate-spin mx-auto" />
          <p className="text-base font-bold text-stone-700">
            Google検索から日本の伝統情報を調べています…
          </p>
          <p className="text-xs text-stone-400">
            小学4年生がわかりやすいように要約・整理しています
          </p>
        </div>
      )}

      {/* Tab 1: Answer Content */}
      {!loading && activeSubTab === 'answer' && result && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Main Answer Card (8 Cols) */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
              <div>
                <span className="text-xs text-stone-400">検索キーワード</span>
                <h3 className="text-xl sm:text-2xl font-bold font-mincho text-stone-900">
                  「{result.query}」の調べ学習
                </h3>
              </div>

              <button
                onClick={() => handleReadAloud(result.answer)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${
                  isNarrating
                    ? 'bg-red-700 text-white border-red-700'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                <Volume2 className="w-4 h-4" />
                <span>{isNarrating ? 'よみあげ中…' : 'こえで聞く'}</span>
              </button>
            </div>

            {/* Answer Body */}
            <div className="prose prose-stone max-w-none text-stone-800 text-sm sm:text-base leading-relaxed whitespace-pre-wrap">
              {result.answer}
            </div>

            {/* Action to switch to images */}
            {images.length > 0 && (
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl flex items-center justify-between gap-4">
                <div className="text-xs sm:text-sm text-amber-950 font-medium">
                  この伝統に関する実物写真が <strong className="font-bold">{images.length}枚</strong> 見つかりました！
                </div>
                <button
                  onClick={() => setActiveSubTab('images')}
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition-colors whitespace-nowrap shadow-xs"
                >
                  写真ギャラリーを見る →
                </button>
              </div>
            )}
          </div>

          {/* Sources and Web Links (4 Cols) */}
          <div className="lg:col-span-4 space-y-5">
            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center gap-2 text-stone-900 font-bold text-sm border-b border-stone-100 pb-2">
                <Globe className="w-4 h-4 text-blue-600" />
                <span>Google検索の参考元サイト</span>
              </div>

              {result.sources.length > 0 ? (
                <div className="space-y-2.5">
                  {result.sources.map((src, idx) => (
                    <a
                      key={idx}
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block p-3 rounded-xl border border-stone-200 hover:border-blue-400 hover:bg-blue-50/30 transition-all text-xs group"
                    >
                      <div className="font-bold text-blue-700 group-hover:underline line-clamp-2">
                        {src.title}
                      </div>
                      <div className="text-[11px] text-stone-400 truncate mt-1 flex items-center gap-1">
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate">{src.url}</span>
                      </div>
                    </a>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-500">
                  Googleナレッジベースから最新情報を取得しました。
                </p>
              )}
            </div>

            {/* Research Tips for Kids */}
            <div className="bg-stone-50 rounded-2xl border border-stone-200 p-5 space-y-2">
              <div className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                調べ学習ノートの書き方のコツ
              </div>
              <ul className="text-xs text-stone-600 space-y-1.5 pl-3 list-disc">
                <li>「昔の人のどんな願いがあるか」をノートにメモしよう</li>
                <li>「なぜその土地で発展したのか（気候や川など）」に注目しよう</li>
                <li>写真ギャラリーの写真も印刷してノートに貼ってみよう</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Authentic Image Gallery */}
      {!loading && activeSubTab === 'images' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-stone-600">
              「<strong>{searchTerm}</strong>」に関する日本の伝統文化・工芸品・お祭りの写真 ({images.length}件)
            </p>
            <span className="text-xs text-stone-400">写真をタップすると大きく表示されます</span>
          </div>

          {images.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {images.map((img) => (
                <div
                  key={img.id}
                  onClick={() => {
                    sound.playKoto(1);
                    setSelectedModalImage(img);
                  }}
                  className="group relative bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-xs hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
                >
                  <div className="aspect-[4/3] bg-stone-100 overflow-hidden relative">
                    <img
                      src={img.thumbUrl}
                      alt={img.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                      <Maximize2 className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-md" />
                    </div>
                  </div>

                  <div className="p-3 space-y-1">
                    <h4 className="text-xs font-bold text-stone-900 line-clamp-1 group-hover:text-red-700 transition-colors">
                      {img.title}
                    </h4>
                    <p className="text-[11px] text-stone-500 line-clamp-2">
                      {img.description || '伝統文化の実物写真資料'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-16 text-center bg-white rounded-2xl border border-stone-200 p-8 space-y-3">
              <ImageIcon className="w-10 h-10 text-stone-300 mx-auto" />
              <p className="text-base font-bold text-stone-700">写真が見つかりませんでした</p>
              <p className="text-xs text-stone-500">
                別の言葉（例:「漆器」「切子」「ねぶた」「鯉のぼり」など）で検索してみてください。
              </p>
            </div>
          )}
        </div>
      )}

      {/* Image Fullscreen Modal */}
      {selectedModalImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-fade-in">
          <div className="relative bg-white rounded-3xl overflow-hidden max-w-3xl w-full shadow-2xl border border-stone-200 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-stone-100">
              <h3 className="text-sm font-bold text-stone-900 truncate pr-4">
                {selectedModalImage.title}
              </h3>
              <button
                onClick={() => setSelectedModalImage(null)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Image Box */}
            <div className="bg-stone-950 flex-1 flex items-center justify-center p-2 min-h-[300px] overflow-hidden">
              <img
                src={selectedModalImage.url}
                alt={selectedModalImage.title}
                className="max-h-[60vh] max-w-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Modal Footer Description */}
            <div className="p-4 sm:p-6 bg-white space-y-2">
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                {selectedModalImage.description}
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-[11px] text-stone-400">
                <span>提供: {selectedModalImage.author}</span>
                <a
                  href={selectedModalImage.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-blue-600 hover:underline"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>高解像度画像を開く</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
